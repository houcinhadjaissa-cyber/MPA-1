export default function NotFound() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-center">
        <p className="text-emerald-400 text-6xl font-bold font-mono mb-4">404</p>
        <p className="text-white/50 text-lg">Page not found.</p>
      </div>
    </div>
  );
}
